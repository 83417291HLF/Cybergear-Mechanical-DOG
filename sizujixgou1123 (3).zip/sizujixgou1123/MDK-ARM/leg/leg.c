#include "leg.h"
#include <math.h>
#include <stdlib.h>
#include "mpu6500.h"

// ================== ȫ�ֲ�̬������ʼ�� ==================
GaitConfig myGait = {
    .S = 80.0f,
    .yaw_s = 0.0f,
    .H = 38.0f,
    .T_cycle = 0.08f,
    .y_base = 173.2f,
    .timer = 0.0f,
    .stepping_in_place = 0
};

static float target_y_base = 173.2f;

// ------------- ��������Ӧ���� -------------
#define IMU_TERRAIN_GAIN 3.0f
#define MAX_ADAPT_ANGLE 10.0f
#define ANGLE_TO_MM_RATIO 1.8f

// �Ż�����������Ӧ����״̬
typedef struct {
    float offset_z[4];
    float offset_z_filt[4];
    float contact_weight[4];
} TerrainComp;

static TerrainComp terrain = {0};

// ================== ���� ==================
static inline float clamp_f(float v, float min, float max)
{
    return (v < min) ? min : ((v > max) ? max : v);
}

static void update_contact_weight_auto(void)
{
    float base_w = 1.0f;

    for (uint8_t i = 0; i < 4; i++) {

        float phase =
            myGait.timer / myGait.T_cycle +
            ((i == 1 || i == 3) ? 0.5f : 0.0f);

        if (phase >= 1.0f)
            phase -= 1.0f;

        // ֧����Ȩ�ظ�
        if (phase >= 0.5f)
            terrain.contact_weight[i] = base_w;
        else
            terrain.contact_weight[i] = 0.2f;
    }
}

// ================== ��ʼ�� ==================
void quadruped_init(void)
{
    for (uint8_t i = 0; i < 4; i++) {
        init_cybergear(&mi_motor_can1[i], i + 1, Position_mode, &hcan1);
        HAL_Delay(20);
        Set_Cyber_ZeroPos(&mi_motor_can1[i]);
    }

    for (uint8_t i = 0; i < 4; i++) {
        init_cybergear(&mi_motor_can2[i], i + 5, Position_mode, &hcan2);
        HAL_Delay(20);
        Set_Cyber_ZeroPos(&mi_motor_can2[i]);
    }
}

// ================== ���� IK ==================
void leg_set_position_idx(uint8_t leg_idx, float x, float y)
{
    float cx = -x;
    float cy = y;

    if (leg_idx >= 2) cx = -cx;

    float L_sq = cx * cx + cy * cy;
    float L = sqrtf(L_sq);

    L = clamp_f(L, fabsf(L1 - L2_EFF) + 5.0f, (L1 + L2_EFF) * 0.95f);

    float psi = asinf(clamp_f(-cx / L, -1.0f, 1.0f));
    float phi = acosf(clamp_f((L_sq + L1 * L1 - L2_EFF * L2_EFF) /
                              (2.0f * L1 * L), -1.0f, 1.0f));

    float theta1 = -(phi - psi);
    float theta2 = -(phi + psi);

    if (leg_idx < 2) {
        set_position_cybergear(&mi_motor_can1[leg_idx * 2],
                               theta1 + OFFSET_ANGLE, 20, 8, 20);
        set_position_cybergear(&mi_motor_can1[leg_idx * 2 + 1],
                               theta2 + OFFSET_ANGLE, 20, 8, 20);
    } else {
        uint8_t base = (leg_idx - 2) * 2;
        set_position_cybergear(&mi_motor_can2[base],
                               -1.0f * (theta1 + OFFSET_ANGLE), 20, 8, 20);
        set_position_cybergear(&mi_motor_can2[base + 1],
                               -1.0f * (theta2 + OFFSET_ANGLE), 20, 8, 20);
    }
}

// ================== ���Ĳ�̬���£���������Ӧ�棩 ==================
void update_quadruped_gait(float dt)
{
    myGait.y_base += (target_y_base - myGait.y_base) * 1.0f;

    // ��������������Ӧ����
    compute_terrain_adaptive_auto(dt);
    update_contact_weight_auto();

    uint8_t is_moving =
        (fabsf(myGait.S) > 1.0f ||
         fabsf(myGait.yaw_s) > 1.0f ||
         myGait.stepping_in_place);

    if (!is_moving) {

        for (uint8_t i = 0; i < 4; i++) {

            // �Ż�����ֹ״̬�߶Ȱ�������
            float y_target =
                myGait.y_base +
                terrain.offset_z_filt[i] * IMU_TERRAIN_GAIN;

            // ��̬����Ӧֻ�����ڸ߶�
            leg_set_position_idx(i, 0.0f, y_target);
        }
        myGait.timer = 0;
        return;
    }

    myGait.timer += dt;
    if (myGait.timer >= myGait.T_cycle)
        myGait.timer -= myGait.T_cycle;

    for (uint8_t i = 0; i < 4; i++) {

        float current_v =
            (i < 2) ? (myGait.S + myGait.yaw_s)
                    : (myGait.S - myGait.yaw_s);

        float phase =
            myGait.timer / myGait.T_cycle +
            ((i == 1 || i == 3) ? 0.5f : 0.0f);

        if (phase >= 1.0f)
            phase -= 1.0f;

        float tx, ty;

        if (phase < 0.5f) {

            float s = phase / 0.5f;
            float sigma = 2.0f * M_PI * s;

            tx = -current_v * 0.5f +
                 current_v * (sigma - sinf(sigma)) /
                 (2.0f * M_PI);

            // �ڶ��ࣺ���Ͳ���Ȩ��
            ty = myGait.y_base +
                 myGait.H * (1.0f - cosf(sigma)) * 0.5f +
                 terrain.offset_z_filt[i] * 0.4f;

        } else {

            float s = (phase - 0.5f) / 0.5f;

            tx = current_v * 0.5f - current_v * s;

            // ֧���ࣺ���ݽӴ�Ȩ�ؼ�ǿѹ�Ȳ���
            ty = myGait.y_base +
                 terrain.offset_z_filt[i] *
                 terrain.contact_weight[i];
        }

        leg_set_position_idx(i, tx, ty);
    }
}

void update_control_from_remote(remoter_t *remote)
{
    if (!remote->online) {

        // ���߱����������˶���
        myGait.S = 0.0f;
        myGait.yaw_s = 0.0f;
        myGait.stepping_in_place = 0;

        // ������ң������ʱҲ�� terrain ����Ӧ����
        for (uint8_t i = 0; i < 4; i++) {
            terrain.offset_z[i] = 0.0f;
            terrain.offset_z_filt[i] = 0.0f;
        }

        return;
    }

    // CH5��ch[4]����Ϊ�˶�ʹ�ܿ���
    if (remote->rc.ch[4] != 0) {

        // -------- ǰ���ٶȿ��� (ͨ��1��ch[2]) --------
        int16_t raw_ch1 = remote->rc.ch[2];

        float target_S;

        if (abs(raw_ch1) < 40) {
            target_S = 0.0f;
        } else {
            target_S = (float)raw_ch1 * (65.0f / 670.0f);
        }

        // ƽ���˲�
        myGait.S = myGait.S * 0.8f + target_S * 0.2f;

        // -------- ת����� (ͨ��0��ch[3]) --------
        int16_t raw_ch0 = remote->rc.ch[0];

        float target_yaw;

        if (abs(raw_ch0) < 40) {
            target_yaw = 0.0f;
        } else {
            target_yaw = -(float)raw_ch0 * (45.0f / 670.0f);
        }

        myGait.yaw_s = myGait.yaw_s * 0.8f + target_yaw * 0.2f;

    } else {

        // �˶�δʹ��ʱ����
        myGait.S = 0.0f;
        myGait.yaw_s = 0.0f;
    }

    // -------- ԭ��̤������ (ͨ��6��ch[5]) --------
    myGait.stepping_in_place =
        (remote->rc.ch[5] > 500);

    // -------- �߶��Զ��л� (ͨ��8��ch[7]) --------
    int16_t raw_ch8 = remote->rc.ch[7];

    if (raw_ch8 > 500) {

        // ����̬
        target_y_base = 160.0f;

    } else if (raw_ch8 < -500) {

        // ����̬
        target_y_base = 220.0f;

    } else {

        // Ĭ�ϸ߶�
        target_y_base = 173.2f;
    }

    // -------- ��ȫ�޷� --------
    myGait.S =
        clamp_f(myGait.S, -70.0f, 70.0f);

    myGait.yaw_s =
        clamp_f(myGait.yaw_s, -50.0f, 50.0f);
}

static void compute_terrain_adaptive_auto(float dt)
{
    // ��ȡ��̬��
    float roll  = clamp_f(imu.rol0, -MAX_ADAPT_ANGLE, MAX_ADAPT_ANGLE);
    float pitch = clamp_f(imu.pit0, -MAX_ADAPT_ANGLE, MAX_ADAPT_ANGLE);

    // �ѽǶ�ת��Ϊƽ��߶ȱ仯
    float dz_roll  = roll  * ANGLE_TO_MM_RATIO;
    float dz_pitch = pitch * ANGLE_TO_MM_RATIO;

    // ���ݻ�����б�������ȸ߶�
    // ����˳��0-LF��1-LH��2-RH��3-RF
    terrain.offset_z[0] =  dz_roll + dz_pitch;   // ��ǰ��
    terrain.offset_z[1] =  dz_roll - dz_pitch;   // �����
    terrain.offset_z[2] = -dz_roll - dz_pitch;   // �Һ���
    terrain.offset_z[3] = -dz_roll + dz_pitch;   // ��ǰ��

    // �����˶��ٶ�����Ӧ����ǿ��
    float move_ratio = clamp_f(fabsf(myGait.S) / 60.0f, 0.0f, 1.0f);
    float adaptive_k = 1.0f - 0.6f * move_ratio;

    for (uint8_t i = 0; i < 4; i++) {

        float dz = terrain.offset_z[i] * adaptive_k;

        // һ���˲�
        terrain.offset_z_filt[i] =
            terrain.offset_z_filt[i] * 0.92f + dz * 0.08f;

        // �߶��޷�
        terrain.offset_z_filt[i] =
            clamp_f(terrain.offset_z_filt[i], -30.0f, 30.0f);
    }
}
