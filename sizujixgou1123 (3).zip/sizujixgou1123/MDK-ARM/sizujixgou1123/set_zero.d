sizujixgou1123\set_zero.o: firstsport\set_zero.c
