.\sizujixgou1123\robot_config.o: robot_config\robot_config.c
